package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.border.TitledBorder;

public class FrameCart extends JFrame {

   public FrameCart() {
      BaseSet frame = new BaseSet();
      
      ImageIcon cart = new ImageIcon("image/frame/carttitle.png");
      JLabel lblCart = new JLabel(cart);
      lblCart.setBounds(115, 70, 350, 85);
      frame.add(lblCart);

      if (MyShop.buylist.isEmpty()) {
         JOptionPane.showMessageDialog(null, "장바구니가 비어있습니다.");
      }

      // 폰트
      Font font15 = (new Font("MONOSPACED", Font.BOLD, 15));
      Font font17 = (new Font("MONOSPACED", Font.BOLD, 17));

      JPanel basket = new JPanel();

      basket.setBounds(30, 190, 530, 520);
      basket.setBackground(Color.lightGray);
      basket.setBorder(new TitledBorder(null, "LIST", TitledBorder.LEADING, TitledBorder.TOP,
            new Font("MONOSPACED", Font.BOLD, 25), new Color(000, 000, 000)));
      frame.add(basket);
      basket.setLayout(null);

      // 삭제, 항목, 수량체크, 가격
      JLabel column1 = new JLabel("삭제");
      column1.setFont(font17);
      column1.setBounds(20, 20, 80, 50);
      basket.add(column1);

      JLabel column2 = new JLabel("항목");
      column2.setFont(font17);
      column2.setBounds(160, 20, 80, 50);
      basket.add(column2);

      JLabel column3 = new JLabel("수량체크");
      column3.setFont(font17);
      column3.setBounds(310, 20, 80, 50);
      basket.add(column3);

      JLabel column4 = new JLabel("가격");
      column4.setFont(font17);
      column4.setBounds(450, 20, 80, 50);
      basket.add(column4);

      // 16개의 케이스를 만들고 인덱스변수넣기
      if (!MyShop.buylist.isEmpty()) {
         for (int i = 0; i < MyShop.buylist.size(); i++) {
            switch (i) {
            case 0:
               String Str0 = "";
               Str0 += "        " + MyShop.buylist.get(0).getPrice() + "원       "
                     + MyShop.buylist.get(0).getPrice() * MyShop.buylist.get(0).getCount() + "원     "
                     + MyShop.buylist.get(0).getName();
               JLabel a = new JLabel(Str0);
               a.setBounds(50, 15, 500, 200);
               a.setFont(font15);
               add(a);

               int asp1 = 0;
               asp1 += MyShop.buylist.get(0).getCount();
               JSpinner aa = new JSpinner();
               aa.setValue(asp1);
               aa.setBounds(50,100,50, 25);
               add(aa);

               JButton aaa = new JButton();
               aaa.setBounds(25,100,20, 20);
               aaa.addActionListener(new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e) {
                     int aaaa = (Integer) aa.getValue();
                     if (aaaa > 0 && aaaa < 10) {

                        if (aaaa > MyShop.buylist.get(0).getCount()) {
                           JOptionPane.showMessageDialog(null, "수량을 초과했습니다");
                           MyShop.getMyShop(); // 다시 창띄우기
                        } else if (aaaa == MyShop.buylist.get(0).getCount()) {
                           JOptionPane.showMessageDialog(null, "장바구니에서 제외됐습니다");
                           MyShop.buylist.get(0).minusCount(aaaa);
                           MyShop.buylist.remove(0);
                           MyShop.getMyShop(); // 다시 창띄우기
                        } else if (aaaa < MyShop.buylist.get(0).getCount()) {
                           MyShop.buylist.get(0).minusCount(aaaa);
                           JOptionPane.showMessageDialog(null, "수량이 정상 변경 됐습니다.");
                           MyShop.getMyShop(); // 다시 창띄우기
                        }
                     } else {
                        JOptionPane.showMessageDialog(null, "1-9까지의 수량을 입력해주세요");
                        MyShop.getMyShop(); // 다시 창띄우기
                     }
                  }
               });
               add(aaa);
               break;
            }
         }
      }
      
      // 로고들
      JLabel lblImage = new JLabel();
      JButton lblLED = new JButton();
      JButton lblTitle = new JButton();
      frame.logoSet(lblImage, lblLED, lblTitle);

      // main버튼
      ImageIcon main = new ImageIcon("image/frame/main.png");
      ImageIcon mainon = new ImageIcon("image/frame/mainon.png");
      JButton btnMain = new JButton();
      frame.ButtonSet(btnMain, main, mainon);
      btnMain.setBounds(30, 740, 120, 60);
      frame.add(btnMain);
      btnMain.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            new FrameStart();
            frame.dispose();
         }
      });
      
      // order버튼
      ImageIcon order = new ImageIcon("image/frame/order.png");
      ImageIcon orderon = new ImageIcon("image/frame/orderon.png");
      JButton btnOrder = new JButton();
      frame.ButtonSet(btnOrder, order, orderon);
      btnOrder.setBounds(440, 740, 120, 60);
      frame.add(btnOrder);
      btnOrder.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            new FrameOrder();
            frame.dispose();
         }
      });

      JLabel effect = new JLabel();
      frame.backEffect(effect);

      frame.setVisible(true);
   }// 생성자
}// class