package Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Frame.FrameGender.GenSuCo;
import Frame.FrameGender.GenSuLt;
import Frame.FrameGender.GenSuMt;

public class FrameProductSummerF extends JFrame {

   public static class ProSuLtF extends JFrame {
      public ProSuLtF() {
         // 객체 생성
         BaseSet frame = new BaseSet();
         ProductSet set = new ProductSet();
         // 로고들
         JLabel lblImage = new JLabel(); // 이미지 라벨
         JButton lblLED = new JButton(); // led로고 버튼
         JButton lblTitle = new JButton();// 제목 버튼
         frame.logoSet(lblImage, lblLED, lblTitle);
         // 상단 타이틀(동그라미)
         ImageIcon sult = new ImageIcon("image/product/여라.png");
         JLabel suLight = new JLabel(sult); // 이미지를 라벨에 대입
         suLight.setBounds(115, 70, 350, 110); // 라벨 사이즈 설정
         frame.add(suLight);// 프레임에 smLight 라벨 넣어주기

         frame.add(set.getLblSet1());// 왼쪽 set 구분1
         frame.add(set.getLblSet2());// 왼쪽 set 구분2
         frame.add(set.getLblSet3());// 왼쪽 set 구분3
         frame.add(set.getBtnAdd1());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd2());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd3());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnShow1());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow2());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow3());// 오른쪽 돋보기 버튼 이미지

         set.getBtnShow1().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set1");
               ImageIcon set1 = new ImageIcon("image/product/female/f여라1.png");
               JLabel ltSet1 = new JLabel(set1); // 라벨에 이미지 붙여주기
               ltSet1.setBounds(25, 25, 485, 485); // 라벨 사이즈 설정
               newF.add(ltSet1); // 프레임 안에 라벨 붙여주기
               newF.setVisible(true);// 보여주기
            }
         });

         set.getBtnShow2().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set2");
               ImageIcon set2 = new ImageIcon("image/product/female/f여라2.png");
               JLabel ltSet2 = new JLabel(set2);
               ltSet2.setBounds(25, 25, 485, 485);
               newF.add(ltSet2);
               newF.setVisible(true);
            }
         });

         set.getBtnShow3().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set3");
               ImageIcon set3 = new ImageIcon("image/product/female/f여라3.png");
               JLabel ltSet3 = new JLabel(set3);
               ltSet3.setBounds(25, 25, 485, 485);
               newF.add(ltSet3);
               newF.setVisible(true);
            }
         });
         set.getBtnAdd1().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd2().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd3().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         // back버튼
         JButton btnBack = new JButton();
         frame.goBack(btnBack);

         btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new GenSuLt();
               frame.dispose();
            }
         });
         // main버튼
         JButton btnMain = new JButton();
         frame.goMain(btnMain);
         // 배경효과 처리
         JLabel effect = new JLabel();
         frame.backEffect(effect);

         frame.setVisible(true);

      }// 생성자 end

   }// 내부 class end

   public static class ProSuCoF extends JFrame {
      public ProSuCoF() {
         BaseSet frame = new BaseSet();
         ProductSet set = new ProductSet();
         // 로고들
         JLabel lblImage = new JLabel();
         JButton lblLED = new JButton();
         JButton lblTitle = new JButton();
         frame.logoSet(lblImage, lblLED, lblTitle);
         // 상단 타이틀
         ImageIcon suco = new ImageIcon("image/product/여쿨.png");
         JLabel suCool = new JLabel(suco);
         suCool.setBounds(115, 70, 350, 110);
         frame.add(suCool);

         frame.add(set.getLblSet1());// 왼쪽 set 구분1
         frame.add(set.getLblSet2());// 왼쪽 set 구분2
         frame.add(set.getLblSet3());// 왼쪽 set 구분3
         frame.add(set.getBtnAdd1());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd2());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd3());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnShow1());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow2());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow3());// 오른쪽 돋보기 버튼 이미지

         set.getBtnShow1().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set1");

               ImageIcon set1 = new ImageIcon("image/product/female/f여쿨1.png");
               JLabel coSet1 = new JLabel(set1);
               coSet1.setBounds(25, 25, 485, 485);
               newF.add(coSet1);
               newF.setVisible(true);
            }
         });
         set.getBtnShow2().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set2");

               ImageIcon set2 = new ImageIcon("image/product/female/f여쿨2.png");
               JLabel coSet2 = new JLabel(set2);
               coSet2.setBounds(25, 25, 485, 485);
               newF.add(coSet2);
               newF.setVisible(true);
            }
         });
         set.getBtnShow3().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set3");

               ImageIcon set3 = new ImageIcon("image/product/female/f여쿨3.png");
               JLabel coSet3 = new JLabel(set3);
               coSet3.setBounds(25, 25, 485, 485);
               newF.add(coSet3);
               newF.setVisible(true);
            }
         });
         set.getBtnAdd1().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd2().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd3().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         // back
         JButton btnBack = new JButton();
         frame.goBack(btnBack);

         btnBack.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               new GenSuCo();
               frame.dispose();

            }
         });
         //main
         JButton btnMain=new JButton();
         frame.goMain(btnMain);
         //배경효과
         JLabel effect=new JLabel();
         frame.backEffect(effect);
         
         frame.setVisible(true);
      }// 생성자 end
   }// 내부 class end
   public static class ProSuMtF extends JFrame {
      public ProSuMtF() {
         BaseSet frame = new BaseSet();
         ProductSet set = new ProductSet();
         // 로고들
         JLabel lblImage = new JLabel();
         JButton lblLED = new JButton();
         JButton lblTitle = new JButton();
         frame.logoSet(lblImage, lblLED, lblTitle);
         // 상단 타이틀
         ImageIcon sumt = new ImageIcon("image/product/여뮤.png");
         JLabel suMute = new JLabel(sumt);
         suMute.setBounds(115, 70, 350, 110);
         frame.add(suMute);

         frame.add(set.getLblSet1());// 왼쪽 set 구분1
         frame.add(set.getLblSet2());// 왼쪽 set 구분2
         frame.add(set.getLblSet3());// 왼쪽 set 구분3
         frame.add(set.getBtnAdd1());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd2());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnAdd3());// 오른쪽 장바구니 버튼 이미지
         frame.add(set.getBtnShow1());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow2());// 오른쪽 돋보기 버튼 이미지
         frame.add(set.getBtnShow3());// 오른쪽 돋보기 버튼 이미지

         set.getBtnShow1().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set1");

               ImageIcon set1 = new ImageIcon("image/product/female/f여뮤1.png");
               JLabel mtSet1 = new JLabel(set1);
               mtSet1.setBounds(25, 25, 485, 485);
               newF.add(mtSet1);
               newF.setVisible(true);
            }
         });
         set.getBtnShow2().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set2");

               ImageIcon set2 = new ImageIcon("image/product/female/f여뮤2.png");
               JLabel mtSet2 = new JLabel(set2);
               mtSet2.setBounds(25, 25, 485, 485);
               newF.add(mtSet2);
               newF.setVisible(true);
            }
         });
         set.getBtnShow3().addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               JFrame newF = new JFrame();
               set.newFrame(newF);
               newF.setTitle("Set3");

               ImageIcon set3 = new ImageIcon("image/product/female/f여뮤3.png");
               JLabel mtSet3 = new JLabel(set3);
               mtSet3.setBounds(25, 25, 485, 485);
               newF.add(mtSet3);
               newF.setVisible(true);
            }
         });
         set.getBtnAdd1().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd2().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         set.getBtnAdd3().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
         });
         // back
         JButton btnBack = new JButton();
         frame.goBack(btnBack);

         btnBack.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
               new GenSuMt();
               frame.dispose();

            }
         });
         //main
         JButton btnMain=new JButton();
         frame.goMain(btnMain);
         //배경효과
         JLabel effect=new JLabel();
         frame.backEffect(effect);
         
         frame.setVisible(true);
      }// 생성자 end
   }// 내부 class end
   
}// 외부 class end